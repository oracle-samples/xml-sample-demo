select XDB_MONITOR.GETSTATISTICS().extract('/')
  from dual
/
