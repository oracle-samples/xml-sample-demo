// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Insert Anchor": "アンカーの挿入",
  "Anchor name": "アンカーの名前",
  "Delete": "削除"
};