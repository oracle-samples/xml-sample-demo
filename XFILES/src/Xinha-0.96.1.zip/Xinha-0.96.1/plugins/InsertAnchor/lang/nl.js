// I18N constants
// LANG: "de", ENCODING: UTF-8
// translated: Raimund Meyer xinha@ray-of-light.org
{
  "Insert Anchor": "Anker invoegen",
  "Anchor name": "Naam (ID)",
  "Delete": "Verwijderen"
};
