// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
	"Insert Smiley": "スマイリーの挿入",
	"Smiley": "スマイリー",
	"Cancel": "中止"
};