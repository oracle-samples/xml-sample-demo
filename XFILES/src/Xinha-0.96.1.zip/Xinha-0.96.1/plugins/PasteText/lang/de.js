// I18N constants
// LANG: "de", ENCODING: UTF-8
{
  "Paste as Plain Text": "unformatierten Text einfügen",
	"Insert text in new paragraph" : "Neue Absätze eifügen"
};
