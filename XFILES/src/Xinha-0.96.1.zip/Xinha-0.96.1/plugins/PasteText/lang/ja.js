// I18N constants
// LANG: "ja", ENCODING: UTF-8
{
  "Paste as Plain Text": "プレーンテキストとして貼り付け"
};