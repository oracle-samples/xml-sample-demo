// I18N constants
// LANG: "nl", ENCODING: UTF-8
// Author: Maarten Molenschot, maarten@nrgmm.nl
{
  "Paste as Plain Text": "Kopieer als platte tekst (geen opmaak)"
};
