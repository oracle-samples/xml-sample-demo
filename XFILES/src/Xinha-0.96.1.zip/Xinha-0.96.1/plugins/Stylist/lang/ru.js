// I18N constants
// LANG: "ru", ENCODING: UTF-8
{
  "Styles": "Стили"
};