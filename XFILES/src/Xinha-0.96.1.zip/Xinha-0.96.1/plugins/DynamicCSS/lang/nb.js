// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Default": "Standard",
  "Undefined": "Udefinert",
  "Choose stylesheet": "Velg stilsett"
};