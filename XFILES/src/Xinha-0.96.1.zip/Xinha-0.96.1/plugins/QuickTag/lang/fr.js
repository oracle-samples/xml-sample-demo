// I18N constants
// LANG: "fr", ENCODING: UTF-8
{ 
  "Quick Tag Editor": "Editeur rapide de balise",
  "Enter the TAG you want to insert": "Entrez la balise que vous voulez insérer",
  "You have to select some text": "Vous devez sélectionner du texte",
  "There are some unclosed quote": "Il y a des apostrophes mal fermées",
  "This attribute already exists in the TAG": "Cet attribute existe déjà sur cette balise",
  "No CSS class avaiable": "Pas de classe CSS accessible",
  "OPTIONS": "OPTIONS",
  "ATTRIBUTES": "ATTRIBUTS",
  "TAGs": "Balises",
  "Colors": "Couleurs",
  "Ok": "OK",
  "Cancel": "Annuler"
};