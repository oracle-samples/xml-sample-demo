// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{ 
  "Quick Tag Editor": "Kjapp TAGG-Editor",
  "Enter the TAG you want to insert": "Skriv inn taggen du vil ønsker å sette inn",
  "You have to select some text": "Du må velge noe tekst",
  "There are some unclosed quote": "Det mangler et hermetegn",
  "This attribute already exists in the TAG": "Denne attributten eksisterer allerede i taggen",
  "No CSS class avaiable": "Ingen CSS klasse tilgjengelig",
  "OPTIONS": "EGENSKAPER",
  "ATTRIBUTES": "ATTRIBUTTER",
  "TAGs": "TAGGer",
  "Colors": "Farger",
  "Ok": "OK",
  "Cancel": "Avbryt"
};