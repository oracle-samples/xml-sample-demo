// I18N constants
// LANG: "de", ENCODING: UTF-8
// Author: Udo Schmal (gocher), http://www.schaffrath-neuemedien.de/, udo.schmal@t-online.de
{
  "Abbreviation": "Abkürzung",
  "Expansion:": "Erklärung:",
  "Delete": "Löschen"
};
