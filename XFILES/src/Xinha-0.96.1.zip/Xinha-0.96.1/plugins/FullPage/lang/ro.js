// I18N for the FullPage plugin
// LANG: "en", ENCODING: UTF-8
// Author: Mihai Bazon, http://dynarch.com/mishoo
{
  "Alternate style-sheet:": "Template CSS alternativ:",
  "Background color:": "Culoare de fundal:",
  "Cancel": "Renunţă",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "Proprietăţile documentului",
  "Document title:": "Titlul documentului:",
  "OK": "Acceptă",
  "Primary style-sheet:": "Template CSS principal:",
  "Text color:": "Culoare text:"
};
