// I18N constants
// LANG: "es", ENCODING: UTF-8
// translated: Derick Leony <dleony@gmail.com>
{
  "Edit HTML for selected text": "Editar código HTML del texto seleccionado",
  "Tag Editor": "Editor de Etiquetas"
};
